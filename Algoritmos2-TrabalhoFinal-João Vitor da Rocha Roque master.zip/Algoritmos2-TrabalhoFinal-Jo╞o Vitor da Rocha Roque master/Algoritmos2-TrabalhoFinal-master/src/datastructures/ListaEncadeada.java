package datastructures;

import java.io.FileReader;
import java.util.Comparator;
import java.util.Scanner;

import comparators.OrdenaPorEmail;
import interfaces.Iterador;
import interfaces.Predicado;
import model.Aluno;
import model.Celula;

/**
 * 
 * @author jo�o.Rocha

public class ListaEncadeada<T> {

	private Celula<T> primeira;
	private Celula<T> ultima;
	 *
	 */

	class ListaEncadeadaIterador implements Iterador<T>{
		//o iterador comeca pela primeira celula
		Celula<T> posicaoAtual = primeira;

		
		@Override
		public boolean hasNext() {
			if(posicaoAtual != null) {
				return true;
			}
			return false;
		}

		
		@Override
		public T next() {
			if(posicaoAtual == null) {
				return null;
			}
			T elemento = posicaoAtual.getElemento();
			posicaoAtual = posicaoAtual.getProxima();
			
			
			return elemento;
			
		}
	}
	
	
	public void append(T dado) {
		//cria uma celula e coloca o elemento dentro dela
		Celula<T> celula = new Celula<T>();
		celula.setElemento(dado);
		
		//se nao existe nenhuma celula na lista, ou seja, se a primeira eh nula
		if(primeira == null){
			//a celula criada se torna a primeira
			primeira = celula;
			
		} else {
			//se existe alguma celula na lista, entao eh criada a ligacao da nova celula
			//com a que era a ultima
			celula.setAnterior(ultima);
			ultima.setProxima(celula);
		}
		
		//por fim, a celula adiciona se torna a ultima
		ultima = celula;
	}

	
	public void addFirst(T dado) {
		//cria uma nova celula e coloca o elemento dentro dela
		Celula<T> celula = new Celula<T>();
		celula.setElemento(dado);
		
		//posiciona a nova celula como a primeira, criando as ligacoes corretamente
		celula.setProxima(primeira);
		primeira.setAnterior(celula);
		
		//a celula criada se torna a primeira
		this.primeira = celula;
	}

	
	public T search(T key, Comparator<T> cmp) {
		//cria um novo iterador apontando para a primeira celula da lista
		Iterador<T> iterador = iterador();
		
		//enquanto houver uma proxima celula na lista, vai percorrendo
		while(iterador.hasNext()) {
			//pega o elemento atual
			T elementoAtual = iterador.next();
			
			//compara pra ver se entra dentro dos criterios definidos no comparable informado
			//por parametro
			if(cmp.compare(key, elementoAtual) == 0){
				//se atender aos criterios, retorna o elemento encontrado
				return elementoAtual;
			}
		}

		//se nenhum elemento bater com os criterios de busca retorna null
		return null;
	}


	public void printObjects() {
		Iterador<T> iterador = iterador();
		
		while(iterador.hasNext()) {
			T elementoAtual = iterador.next();
			System.out.println(elementoAtual);
		}
	}

	
	public Iterador<T> iterador() {
		return new ListaEncadeadaIterador();
	}

	
	public void removeIf(Predicado<T> predicado) {
		//cria variavel celulaAtual que ira percorrer a lista, comecando pela primeira celula
		Celula<T> celulaAtual = primeira;

		//percorre toda a lista removendo todas as celulas e seus elementos que atendam ao predicado
		do {
			//testa se o elemento da celula atual atende aos criterios do predicado
			if (predicado.teste(celulaAtual.getElemento())) {
				
				//se os criteriores baterem e for a primeira celula da lista
				//ela eh removida
				if (celulaAtual.equals(primeira)) {
					removeDoComeco();

				} else {
					//se os criterios baterem mas nao for a primeira celula da lista
					//entao ela eh removida, trocando os apontamentos das celulas
					//anterior e proxima
					remove(celulaAtual);
				}
			}
			
			//avanca pra proxima celula
			celulaAtual = celulaAtual.getProxima();
			
		} while (celulaAtual != null); //enquanto houver proxima celula, vai testando o predicado
	}

	private void remove(Celula<T> celulaAtual) {
		Celula<T> anterior = celulaAtual.getAnterior();
		Celula<T> proxima = celulaAtual.getProxima();
		anterior.setProxima(proxima);

		//se a celula a ser removida for a ultima, entao a celula anterior
		//passa a ser a "nova" ultima
		if (celulaAtual.equals(ultima)) {
			ultima = anterior;
		} else {
			//se nao for a ultima, entao eh necessario apontar a proxima celula
			//para a anterior, removendo a atual do "meio"
			proxima.setAnterior(anterior);
		}
	}

	
	
	private void removeDoComeco() {
		if(primeira.getProxima() == null){
			//se nao houver proxima celula, ou seja, ter apenas uma celula na lista
			//entao torna a lista vazia, alterando as variaveis ultima e primeira pra null
			ultima = null;
			primeira = null;
		} else {
			//se houver uma proxima celula, entao ela se torna a nova primeira
			primeira = primeira.getProxima();
			primeira.setAnterior(null);
		}
	}
	
	public void remove(T dado) {
		//cria variavel celulaAtual que ira percorrer a lista, comecando pela primeira celula
		Celula<T> celulaAtual = primeira;

		//percorre toda a lista removendo todas as celulas e seus elementos que atendam ao predicado
		do {
			//testa se o elemento da celula atual eh igual ao elemento a ser removido
			if (celulaAtual.getElemento().equals(dado)) {
				
				//se os criteriores baterem e for a primeira celula da lista
				//ela eh removida
				if (celulaAtual.equals(primeira)) {
					removeDoComeco();

				} else {
					//se os criterios baterem mas nao for a primeira celula da lista
					//entao ela eh removida, trocando os apontamentos das celulas
					//anterior e proxima
					remove(celulaAtual);
				}
			}
			
			//avanca pra proxima celula
			celulaAtual = celulaAtual.getProxima();
			
		} while (celulaAtual != null); //enquanto houver proxima celula, vai testando o predicado
	}
	
	public static ListaEncadeada<model.Aluno> loadFromFile(FileReader arquivo){
		ListaEncadeada<Aluno> alunos = new ListaEncadeada<>();
		Scanner sc;

		sc = new Scanner(arquivo);
		sc.useDelimiter("[,\n]");

		while (sc.hasNext()) {
			Aluno aluno = new Aluno();
			aluno.setMatricula(sc.next());
			aluno.setNome(sc.next());
			aluno.setEmail(sc.next());
			aluno.setIdade(sc.nextInt());
			aluno.setSexo(sc.next());
			aluno.setEmpresa(sc.next());
			aluno.setCidade(sc.next());
			
			alunos.append(aluno);
		}

		sc.close();
		
		return alunos;
	}

	public static ListaEncadeada<Aluno> loadFromFile(FileReader arquivo, OrdenaPorEmail ordenaPorEmail) {
		
		return null;
	}
}
