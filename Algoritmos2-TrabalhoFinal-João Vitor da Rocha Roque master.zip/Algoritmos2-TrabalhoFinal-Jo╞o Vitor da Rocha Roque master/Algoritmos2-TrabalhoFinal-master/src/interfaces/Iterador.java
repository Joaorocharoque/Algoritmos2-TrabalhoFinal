package interfaces;

public interface Iterador<T> {

	boolean hasNext();

	T next();

}
