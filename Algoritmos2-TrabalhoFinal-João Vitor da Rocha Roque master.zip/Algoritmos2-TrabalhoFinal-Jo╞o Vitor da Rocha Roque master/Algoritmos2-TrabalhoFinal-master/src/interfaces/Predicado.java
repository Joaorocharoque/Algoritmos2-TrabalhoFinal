package interfaces;

public interface Predicado<T> {
	boolean teste(T objeto);
}
